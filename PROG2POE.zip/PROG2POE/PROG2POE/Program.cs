﻿using System;
using System.Collections.Generic;

namespace CreateApp
{
    // Class for an ingredient
    class Ingredient
    {
        public string Name { get; set; }
        public double Amount { get; set; }
        public string Measurement { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    // Class for a step in the recipe
    class Step
    {
        public string Details { get; set; }
    }

    // Class for a recipe
    class Recipe
    {
        // List to store ingredients and steps
        public List<Ingredient> Ingredients { get; set; }
        public List<Step> Steps { get; set; }
        public string Name { get; set; }

        // Event to notify when calories exceed 300
        public event Action<string> CaloriesExceeded;

        // Method to calculate total calories
        public double CalculateTotalCalories()
        {
            double totalCalories = 0;
            foreach (var ingredient in Ingredients)
            {
                totalCalories += ingredient.Calories;
            }
            return totalCalories;
        }

        // Display recipe details
        public void Display()
        {
            Console.WriteLine($"Recipe: {Name}");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in Ingredients)
            {
                Console.WriteLine($"{ingredient.Amount} {ingredient.Measurement} of {ingredient.Name}");
            }

            Console.WriteLine("The order of steps:");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i].Details}");
            }
        }

        // Scale the recipe
        public void Scale(double scale)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Amount *= scale;
            }
        }

        // Check if calories exceed 300 and raise event if true
        public void CheckCalories()
        {
            if (CalculateTotalCalories() > 300)
            {
                CaloriesExceeded?.Invoke(Name);
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Recipe> recipes = new List<Recipe>();

            while (true)
            {
                Recipe recipe = new Recipe();
                Console.Write("Enter the name of the recipe: ");
                recipe.Name = Console.ReadLine();

                recipe.Ingredients = new List<Ingredient>();
                Console.Write("How many ingredients will you be using? ");
                int ingredientCount = int.Parse(Console.ReadLine());
                for (int i = 0; i < ingredientCount; i++)
                {
                    Ingredient ingredient = new Ingredient();
                    Console.Write($"Please enter ingredient {i + 1} name: ");
                    ingredient.Name = Console.ReadLine();
                    Console.Write($"Enter the amount for {ingredient.Name}: ");
                    ingredient.Amount = double.Parse(Console.ReadLine());
                    Console.Write($"What are the measurements for {ingredient.Name}? ");
                    ingredient.Measurement = Console.ReadLine();
                    Console.Write($"Enter the number of calories for {ingredient.Name}: ");
                    ingredient.Calories = double.Parse(Console.ReadLine());
                    Console.Write($"Enter the food group for {ingredient.Name}: ");
                    ingredient.FoodGroup = Console.ReadLine();
                    recipe.Ingredients.Add(ingredient);
                }

                recipe.Steps = new List<Step>();
                Console.Write("How many steps will there be in the recipe? ");
                int stepCount = int.Parse(Console.ReadLine());
                for (int i = 0; i < stepCount; i++)
                {
                    Step step = new Step();
                    Console.Write($"Enter step {i + 1} details: ");
                    step.Details = Console.ReadLine();
                    recipe.Steps.Add(step);
                }

                recipes.Add(recipe);

                Console.WriteLine("Recipe added successfully!");

                Console.Write("Do you want to add another recipe? (yes/no): ");
                string addAnother = Console.ReadLine();
                if (addAnother.ToLower() != "yes")
                    break;
            }

            Console.WriteLine("Recipes:");
            recipes.Sort((r1, r2) => string.Compare(r1.Name, r2.Name)); // Sort recipes by name
            foreach (var recipe in recipes)
            {
                recipe.Display();
                Console.WriteLine($"Total Calories: {recipe.CalculateTotalCalories()}");
                recipe.CheckCalories();
                Console.WriteLine();
            }

            Console.ReadLine();
        }
    }
}
